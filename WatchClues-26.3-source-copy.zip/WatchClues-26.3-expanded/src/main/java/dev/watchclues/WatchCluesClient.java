package dev.watchclues;

import dev.watchclues.config.ConfigStore;
import dev.watchclues.module.ModuleRegistry;
import dev.watchclues.module.ModuleSpec;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.VanillaHudElements;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import com.mojang.blaze3d.platform.InputConstants;

public final class WatchCluesClient implements ClientModInitializer {
    public static final String MOD_ID = "watchclues";
    private static KeyMapping openGuiKey;

    @Override
    public void onInitializeClient() {
        ModuleRegistry.registerDefaults();
        ConfigStore.load();
        var category = KeyMapping.Category.register(ResourceLocation.fromNamespaceAndPath(MOD_ID, "general"));
        openGuiKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.watchclues.open_gui", InputConstants.Type.KEYSYM, InputConstants.KEY_RIGHT_SHIFT, category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.consumeClick()) {
                client.setScreen(new WatchCluesScreen());
            }
            if (client.player != null && client.level != null) {
                ModuleRegistry.tick(client);
            }
        });

        HudElementRegistry.attachElementBefore(
            VanillaHudElements.CHAT,
            ResourceLocation.fromNamespaceAndPath(MOD_ID, "main_hud"),
            WatchCluesClient::renderHud
        );
    }

    private static void renderHud(GuiGraphicsExtractor graphics, net.minecraft.client.DeltaTracker deltaTracker) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.options.hideGui) return;

        int x = 8, y = 8;
        if (ModuleRegistry.enabled("custom_hud")) {
            graphics.fill(x - 4, y - 4, x + 180, y + 43, 0xB8171923);
            graphics.drawString(client.font, Component.literal("WATCHCLUES"), x, y, 0xFFFF7777);
            y += 13;
            if (ModuleRegistry.enabled("coordinates")) {
                var p = client.player.blockPosition();
                graphics.drawString(client.font, Component.literal("XYZ " + p.getX() + " " + p.getY() + " " + p.getZ()), x, y, 0xFFFFFFFF);
                y += 12;
            }
            if (ModuleRegistry.enabled("fps_ping")) {
                String ping = "Ping: n/a";
                try {
                    var info = client.getConnection().getPlayerInfo(client.player.getUUID());
                    if (info != null) ping = "Ping: " + info.getLatency() + " ms";
                } catch (Exception ignored) { }
                graphics.drawString(client.font, Component.literal("FPS: " + client.getFps() + "  " + ping), x, y, 0xFFB7BAC8);
            }
        }
        if (ModuleRegistry.enabled("spectator_clues")) {
            var names = ModuleRegistry.spectatorNames();
            int sy = 60;
            for (String name : names.stream().limit(5).toList()) {
                graphics.fill(4, sy - 3, 260, sy + 11, 0xCC171923);
                graphics.drawString(client.font, Component.literal("Spectator clue: " + name), 8, sy, 0xFFFFD166);
                sy += 15;
            }
        }
    }
}
