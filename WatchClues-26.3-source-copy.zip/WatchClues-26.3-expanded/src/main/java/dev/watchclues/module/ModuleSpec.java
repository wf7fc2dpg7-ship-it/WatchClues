package dev.watchclues.module;

public final class ModuleSpec {
    private final String id;
    private final String category;
    private final String description;
    private boolean enabled;

    public ModuleSpec(String id, String category, String description, boolean enabled) {
        this.id = id; this.category = category; this.description = description; this.enabled = enabled;
    }
    public String id() { return id; }
    public String category() { return category; }
    public String description() { return description; }
    public boolean enabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public void toggle() { this.enabled = !this.enabled; }
}
