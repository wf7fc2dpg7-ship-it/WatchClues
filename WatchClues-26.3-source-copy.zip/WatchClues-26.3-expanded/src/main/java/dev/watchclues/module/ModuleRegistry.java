package dev.watchclues.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.world.level.GameType;
import net.minecraft.network.chat.Component;
import java.util.*;

public final class ModuleRegistry {
    private static final Map<String, ModuleSpec> MODULES = new LinkedHashMap<>();
    private static final Set<String> LAST_SPECTATORS = new HashSet<>();
    private static final List<String> SPECTATORS = new ArrayList<>();
    private static long lastScan;
    private ModuleRegistry() {}

    public static void registerDefaults() {
        add("custom_hud", "HUD", "Main information panel", true);
        add("coordinates", "HUD", "Player coordinates", true);
        add("fps_ping", "HUD", "FPS and latency display", true);
        add("spectator_clues", "Monitoring", "Show spectator mode when exposed by server", true);
        add("player_list_monitor", "Monitoring", "Watch changes to the visible player list", true);
        add("vanish_clues", "Monitoring", "Report visible player-list inconsistencies only", true);
        add("block_esp", "Visuals", "Highlight selected blocks in loaded client chunks", false);
        add("storage_highlight", "Visuals", "Highlight loaded storage blocks", false);
        add("entity_outlines", "Visuals", "Outline visible entities", false);
        add("fullbright", "Visuals", "Increase client brightness", false);
        add("stash_finder", "Exploration", "Find clusters of storage blocks in loaded chunks", false);
        add("chunk_inspector", "Exploration", "Show current chunk coordinates", false);
        add("waypoints", "Exploration", "Store and show saved coordinates", true);
        add("storage_labels", "Exploration", "Label storage blocks visible to client", false);
        add("notifications", "Alerts", "Show alert messages", true);
        add("sound_alerts", "Alerts", "Play optional notification sounds", false);
        add("performance_dashboard", "Utilities", "Show client FPS and latency", false);
        add("config_manager", "Utilities", "Save and load module configuration", true);
    }

    private static void add(String id, String category, String desc, boolean enabled) {
        MODULES.put(id, new ModuleSpec(id, category, desc, enabled));
    }
    public static Collection<ModuleSpec> all() { return Collections.unmodifiableCollection(MODULES.values()); }
    public static ModuleSpec get(String id) { return MODULES.get(id); }
    public static boolean enabled(String id) { return MODULES.containsKey(id) && MODULES.get(id).enabled(); }
    public static void toggle(String id) {
        ModuleSpec m = MODULES.get(id);
        if (m != null) { m.toggle(); dev.watchclues.config.ConfigStore.save(); }
    }
    public static void setEnabled(String id, boolean enabled) {
        ModuleSpec m = MODULES.get(id);
        if (m != null) { m.setEnabled(enabled); }
    }
    public static List<String> spectatorNames() { return List.copyOf(SPECTATORS); }

    public static void tick(Minecraft client) {
        long now = System.currentTimeMillis();
        if (now - lastScan < 1000) return;
        lastScan = now;
        if (client.getConnection() == null) return;

        SPECTATORS.clear();
        for (PlayerInfo info : client.getConnection().getOnlinePlayers()) {
            if (info.getGameMode() == GameType.SPECTATOR) {
                String name = info.getProfile().getName();
                if (name != null && !name.isBlank()) {
                    SPECTATORS.add(name);
                    if (!LAST_SPECTATORS.contains(name) && enabled("notifications") && client.player != null) {
                        client.gui.getChat().addMessage(Component.literal(
                            "[WatchClues] Spectator clue: " + name +
                            " (mode visible to your client; does not prove they are watching you)"));
                    }
                }
            }
        }
        LAST_SPECTATORS.clear();
        LAST_SPECTATORS.addAll(SPECTATORS);
    }
}
