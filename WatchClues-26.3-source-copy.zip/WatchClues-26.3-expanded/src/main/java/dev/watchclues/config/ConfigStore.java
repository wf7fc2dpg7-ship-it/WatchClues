package dev.watchclues.config;

import com.google.gson.*;
import dev.watchclues.module.ModuleRegistry;
import dev.watchclues.module.ModuleSpec;
import net.fabricmc.loader.api.FabricLoader;
import java.io.IOException;
import java.nio.file.*;

public final class ConfigStore {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("watchclues.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private ConfigStore() {}

    public static void save() {
        JsonObject root = new JsonObject();
        JsonObject modules = new JsonObject();
        for (ModuleSpec m : ModuleRegistry.all()) modules.addProperty(m.id(), m.enabled());
        root.add("modules", modules);
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(root));
        } catch (IOException e) {
            System.err.println("[WatchClues] Could not save config: " + e.getMessage());
        }
    }

    public static void load() {
        if (!Files.exists(FILE)) { save(); return; }
        try {
            JsonObject root = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            JsonObject modules = root.getAsJsonObject("modules");
            if (modules == null) return;
            for (ModuleSpec m : ModuleRegistry.all()) {
                if (modules.has(m.id())) ModuleRegistry.setEnabled(m.id(), modules.get(m.id()).getAsBoolean());
            }
        } catch (Exception e) {
            System.err.println("[WatchClues] Config unreadable; using defaults: " + e.getMessage());
        }
    }

    public static Path path() { return FILE; }
}
