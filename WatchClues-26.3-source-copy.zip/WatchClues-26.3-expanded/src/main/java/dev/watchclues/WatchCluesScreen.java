package dev.watchclues;

import dev.watchclues.module.ModuleRegistry;
import dev.watchclues.module.ModuleSpec;
import dev.watchclues.config.ConfigStore;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class WatchCluesScreen extends Screen {
    private String filter = "";
    private int scroll;
    private final List<String> categories = new ArrayList<>();
    private int selectedCategory = 0;

    public WatchCluesScreen() {
        super(Component.literal("WatchClues"));
        categories.add("All");
        for (ModuleSpec module : ModuleRegistry.all()) {
            if (!categories.contains(module.category())) categories.add(module.category());
        }
    }

    @Override
    public void render(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, 0xB8000000);
        int w = Math.min(560, width - 24), h = Math.min(390, height - 24);
        int left = (width - w) / 2, top = (height - h) / 2;
        g.fill(left, top, left + w, top + h, 0xFF171923);
        g.fill(left, top, left + w, top + 3, 0xFFFF7777);
        g.drawString(font, Component.literal("WATCHCLUES  /  MODULES"), left + 14, top + 12, 0xFFFF7777);
        g.drawString(font, Component.literal("Right Shift closes this menu • Click a row to toggle"),
            left + 14, top + 27, 0xFFB7BAC8);

        int catY = top + 48;
        for (int i = 0; i < categories.size(); i++) {
            int cx = left + 14 + (i * 75);
            if (cx + 72 > left + w - 10) break;
            g.fill(cx, catY, cx + 70, catY + 17, i == selectedCategory ? 0xFF41465A : 0xFF252936);
            g.drawString(font, Component.literal(categories.get(i)), cx + 4, catY + 4, 0xFFFFFFFF);
        }

        String search = filter.isBlank() ? "(use /watchclues-search in a future update; click categories below)" : filter;
        g.drawString(font, Component.literal("Search: " + search), left + 14, top + 72, 0xFFB7BAC8);

        int rowY = top + 94;
        int shown = 0;
        for (ModuleSpec m : ModuleRegistry.all()) {
            if (selectedCategory > 0 && !m.category().equals(categories.get(selectedCategory))) continue;
            if (!filter.isBlank() && !(m.id() + m.description()).toLowerCase(Locale.ROOT).contains(filter.toLowerCase(Locale.ROOT))) continue;
            if (shown++ < scroll) continue;
            if (rowY > top + h - 32) break;
            g.fill(left + 12, rowY - 3, left + w - 12, rowY + 17, m.enabled() ? 0xFF263C36 : 0xFF242733);
            g.drawString(font, Component.literal((m.enabled() ? "[ON]  " : "[OFF] ") + m.id()),
                left + 20, rowY, m.enabled() ? 0xFF73E0B1 : 0xFFFFFFFF);
            g.drawString(font, Component.literal(m.category() + " — " + m.description()),
                left + 210, rowY, 0xFFB7BAC8);
            rowY += 22;
        }
        g.drawString(font, Component.literal("Config: " + ConfigStore.path().getFileName() + " • Wheel scrolls modules"),
            left + 14, top + h - 19, 0xFFB7BAC8);
        super.render(g, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int w = Math.min(560, width - 24), h = Math.min(390, height - 24);
            int left = (width - w) / 2, top = (height - h) / 2;
            int catY = top + 48;
            for (int i = 0; i < categories.size(); i++) {
                int cx = left + 14 + (i * 75);
                if (cx + 72 > left + w - 10) break;
                if (mouseX >= cx && mouseX <= cx + 70 && mouseY >= catY && mouseY <= catY + 17) {
                    selectedCategory = i; scroll = 0; return true;
                }
            }
            int rowY = top + 94;
            int shown = 0;
            for (ModuleSpec m : ModuleRegistry.all()) {
                if (selectedCategory > 0 && !m.category().equals(categories.get(selectedCategory))) continue;
                if (!filter.isBlank() && !(m.id() + m.description()).toLowerCase(Locale.ROOT).contains(filter.toLowerCase(Locale.ROOT))) continue;
                if (shown++ < scroll) continue;
                if (rowY > top + h - 32) break;
                if (mouseX >= left + 12 && mouseX <= left + w - 12 && mouseY >= rowY - 3 && mouseY <= rowY + 17) {
                    ModuleRegistry.toggle(m.id()); return true;
                }
                rowY += 22;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll = Math.max(0, scroll + (verticalAmount < 0 ? 1 : -1));
        return true;
    }

    @Override public boolean isPauseScreen() { return false; }
}
