# WatchClues 26.3 — expanded source project

This is an original modular Fabric client-side project inspired by common utility-client interface patterns. It is not Meteor or Krypton and does not include their code.

## Included in this source iteration

- Right Shift opens a custom dark module dashboard.
- Module categories and individual on/off toggles.
- HUD with coordinates, FPS and ping (where available).
- Spectator clues when the server exposes spectator game-mode information in the player list.
- Chat alerts for newly observable spectator entries.
- JSON configuration saved to `config/watchclues.json`.
- Module entries prepared for block highlighting, storage highlighting, entity outlines, fullbright, loaded-chunk stash finding, chunk inspection, waypoints, storage labels, vanish clues, sound alerts and performance dashboard.

## Honest implementation status

The GUI, module registry, config persistence, coordinates/FPS/ping HUD and exposed-spectator clue scan are implemented in source. Several advanced modules (block/entity rendering, fullbright, stash scanning, waypoints UI, storage labels, sound alerts, vanish inference, config import/export, searchable input and keybind editor) are currently registered as toggles but are not fully wired up yet. They need additional version-specific rendering and screen work before they function. This archive has not been compiled or runtime-tested, so compatibility fixes may be required.

The client can only inspect chunks and player information the game sends to it. It cannot reveal unloaded chunks or reliably detect staff who are fully hidden by the server. A spectator-mode clue does not prove the player is watching you.

## Requirements

- Minecraft Java 26.3
- Fabric Loader 0.19.5 or compatible 26.3 build
- Matching Fabric API
- Java Development Kit 25
- Gradle compatible with the Loom plugin

## Build

1. Extract the ZIP.
2. Install JDK 25 and confirm `java -version` reports version 25.
3. Open this directory in IntelliJ IDEA or use a compatible Gradle installation.
4. Run `gradle build` (Windows: `gradle.bat build`).
5. If successful, find the JAR under `build/libs/`.
6. Place the JAR into the `mods` folder of your Fabric 26.3 profile, alongside the matching Fabric API.
7. Launch and press Right Shift to open the dashboard.

If the build fails, use the first compiler error to update the affected 26.3 API call against the official Fabric 26.3 documentation.

## Config

Configuration is stored at `.minecraft/config/watchclues.json`. Back up this file before editing it manually.

## License

MIT
